import sys, os, signal, resource

def main():
    expr = sys.stdin.read(30000)
    expr = expr.strip()

    safe_globals = {"__builtins__": None} # 
    safe_locals = {}

    try:
        out = eval(expr, safe_globals, safe_locals)
        print(repr(out))
    except Exception as e:
        print(f"[error] {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()