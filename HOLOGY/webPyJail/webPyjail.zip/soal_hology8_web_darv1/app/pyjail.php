<?php
header('Content-Type: text/html; charset=utf-8');

$MAX_LEN = 30000;

$DENY_PATTERNS = [
  "/(['|\"])+/s",
  '/([(|)])+/s',
  '/([_])+/s'
];

function waf_canon(string $s): string {
    if (class_exists('Normalizer')) {
        $n = Normalizer::normalize($s, Normalizer::FORM_C);
        if ($n !== null) $s = $n;
    }
    for ($i = 0; $i < 3; $i++) {
        $t = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($t === $s) break;
        $s = $t;
    }
    for ($i = 0; $i < 3; $i++) {
        $t = rawurldecode($s);
        if ($t === $s) break;
        $s = $t;
    }
    return $s;
}

function waf_pyjail($input) {
    global $DENY_PATTERNS;
    foreach ($DENY_PATTERNS as $pattern) {
        if (preg_match($pattern, $input)) {
            return $pattern;
        }
    }
    return false;
}

$expr = '';
$out = '';
$err = '';
$code = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $expr = (string)($_POST['expr'] ?? '');

  if (mb_strlen($expr, 'UTF-8') > $MAX_LEN) {
    $err = "Expression too long (>{$MAX_LEN} chars).";
  }

  $canon = $expr;
  if (!$err) {
    $canon = waf_canon($expr);
  }

  if (!$err && preg_match('/[^\x09\x0A\x0D\x20-\x7E]/u', $canon)) {
    $err = "Blocked: non-ASCII characters are not allowed.";
  }

  if (!$err) {
    $hit = waf_pyjail($canon);
    if ($hit !== false) {
        $err = "Blocked by blacklist.";
    }
  }

  if (!$err) {
    $desc = [
      0 => ['pipe', 'r'],
      1 => ['pipe', 'w'],
      2 => ['pipe', 'w'],
    ];
    $env = ['LANG' => 'C', 'PATH' => '/usr/bin:/bin'];
    $cmd = ['python3', '/var/www/html/runner.py'];

    $proc = @proc_open($cmd, $desc, $pipes, null, $env);
    if (!is_resource($proc)) {
      $err = "Failed to start Python runner.";
      $code = 1;
    } else {
      if (false === @fwrite($pipes[0], $expr)) {
        $err = "Failed to write to child stdin.";
      }
      @fclose($pipes[0]);

      $out = @stream_get_contents($pipes[1]) ?: '';
      $e2  = @stream_get_contents($pipes[2]) ?: '';
      @fclose($pipes[1]);
      @fclose($pipes[2]);

      $status = proc_get_status($proc);
      $code   = proc_close($proc);

      if ($e2 !== '') $err = trim($e2);
      if (!$err && $code) $err = "runner exit code={$code}";
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>pyjail</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <style>
    body {
      margin:0;
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      font:14px/1.4 system-ui, Segoe UI, Roboto, Arial, sans-serif;
      color:#111;
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    }
    .card {
      width:100%;
      max-width:880px;
      background:#fafafa;
      border:1px solid #eee;
      border-radius:16px;
      padding:24px 28px;
      box-shadow:0 8px 20px rgba(0,0,0,0.15);
      text-align:center;
    }
    h1 {
      margin-top:0;
    }
    form {
      display:flex;
      gap:8px;
      margin:20px 0;
    }
    input[type=text] {
      flex:1;
      padding:10px 12px;
      border-radius:10px;
      border:1px solid #ddd;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    }
    button {
      padding:10px 14px;
      border:0;
      border-radius:10px;
      background:#6a11cb;
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      color:#fff;
      cursor:pointer;
      font-weight:bold;
      transition:opacity .2s;
    }
    button:hover { opacity:0.9; }
    pre {
      background:#111;
      color:#eee;
      padding:12px;
      border-radius:10px;
      overflow:auto;
      text-align:left;
    }
    .muted { color:#666; font-size:12px; }
    .ok { color:#006400; font-weight:bold; }
    .err { color:#b00020; font-weight:bold; }
  </style>
</head>
<body>
  <div class="card">
    <h1>🐍 piton 🐍</h1>

    <form method="post" action="/pyjail.php">
      <input name="expr" type="text" placeholder="1+1" value="<?=htmlspecialchars($expr)?>" autofocus />
      <button type="submit">Eval</button>
    </form>

    <?php if ($err !== ''): ?>
      <p class="err">[stderr]</p>
      <pre><?=htmlspecialchars($err)?></pre>
    <?php endif; ?>

    <?php if ($out !== ''): ?>
      <p class="ok">[stdout] (exit <?=($code===null?'?':$code)?>)</p>
      <pre><?=htmlspecialchars($out)?></pre>
    <?php elseif ($code !== null && $err === ''): ?>
      <p class="ok">Exit code: <?=htmlspecialchars((string)$code)?></p>
    <?php endif; ?>
  </div>
</body>
</html>